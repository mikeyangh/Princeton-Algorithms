import java.awt.Color;

public class SeamCarver 
{
    //private Color[][] myColor;
    private int [][] colorMatrix;
    private int height, width;
    private boolean isTranspose = false;
    public SeamCarver(Picture picture)                // create a seam carver object based on the given picture
    {
        //myColor = new Color[picture.width()][picture.height()];       
        height = picture.height();
        width = picture.width();
        colorMatrix = new int[width][height];
        //energy = new double[myPicture.width()][myPicture.height()];
        for (int i = 0; i < width; i++)
            for (int j = 0; j < height; j++)
            colorMatrix[i][j] = picture.get(i, j).getRGB();
         //myColor[i][j] = picture.get(i, j);
    }
    public Picture picture()                          // current picture
    {
        if (isTranspose)
            transpose();
        Picture newPicture = new Picture(width, height);
        for (int i = 0; i < width; i++)
        {
            for (int j = 0; j < height; j++)
                //newPicture.set(i, j, myColor[i][j]);
                newPicture.set(i, j, new Color(colorMatrix[i][j]));
        }
        return newPicture;
    }
    public int width()                            // width of current picture
    {
        if (isTranspose)
            return height;
        else
            return width;
    }
    public int height()                           // height of current picture
    {
        if (isTranspose)
            return width;
        else
            return height;
    }
    public  double energy(int x, int y)               // energy of pixel at column x and row y
    {
        if (x < 0 || x >= width || y < 0 || y >= height)
            throw new java.lang.IndexOutOfBoundsException();
        if (x == 0 || x == width-1 || y == 0 || y == height-1)
            return 195075.0;
        return dualgradient(x, y);
    }
    private double dualgradient(int x, int y)
    {
        /*
        Color upColor = myColor[x][y-1];
        Color downColor = myColor[x][y+1];
        Color leftColor = myColor[x-1][y];
        Color rightColor = myColor[x+1][y];
        return squareSum(upColor.getRed(), downColor.getRed()) + squareSum(upColor.getGreen(), downColor.getGreen()) + 
            squareSum(upColor.getBlue(), downColor.getBlue()) + squareSum(leftColor.getRed(), rightColor.getRed()) + 
            squareSum(leftColor.getGreen(), rightColor.getGreen()) + squareSum(leftColor.getBlue(), rightColor.getBlue());*/
        Color upColor = new Color(colorMatrix[x][y-1]);
        Color downColor = new Color(colorMatrix[x][y+1]);
        Color leftColor = new Color(colorMatrix[x-1][y]);
        Color rightColor = new Color(colorMatrix[x+1][y]);
        return squareSum(upColor.getRed(), downColor.getRed()) + squareSum(upColor.getGreen(), downColor.getGreen()) + 
            squareSum(upColor.getBlue(), downColor.getBlue()) + squareSum(leftColor.getRed(), rightColor.getRed()) + 
            squareSum(leftColor.getGreen(), rightColor.getGreen()) + squareSum(leftColor.getBlue(), rightColor.getBlue());
    }
    private double squareSum(double a, double b)
    {
        return (a - b)*(a - b);
    }
/////////////////////////////////////////////////////////////////////////private class SeamSP    
    
    private class SeamSP
    {
        private double[][] distTo;
        private int[][] indexTo;
        
        public SeamSP()
        {
            distTo = new double[width][height];
            indexTo = new int[width][height];
            for (int i = 0; i < height; i++)
            {
                distTo[0][i] = 195075.0;
                indexTo[0][i] = -1;
            }
            for (int i = 1; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    relax(i, j);
                }
            }
        }

        private void relax(int i, int j)
        {
            if (j == 0)
            {
                if (distTo[i-1][0] < distTo[i-1][1])
                {
                    distTo[i][j] = distTo[i-1][0] + energy(i, j);
                    indexTo[i][j] = 0;
                }
                else
                {
                    distTo[i][j] = distTo[i-1][1] + energy(i, j);      
                    indexTo[i][j] = 1;
                }
            }
            else if (j == height-1)
            {
                if (distTo[i-1][j-1] < distTo[i-1][j])
                {
                    distTo[i][j] = distTo[i-1][j-1] + energy(i, j);
                    indexTo[i][j] = j-1;
                }
                else
                {
                    distTo[i][j] = distTo[i-1][j] + energy(i, j);
                    indexTo[i][j] = j;
                }
            }
            else
            {
                double min = Double.MAX_VALUE;
                int minIndex = -1;
                for (int k = j-1; k <= j+1; k++)
                {
                    if (distTo[i-1][k] < min)
                    {
                        min = distTo[i-1][k];
                        minIndex = k;
                    }
                }
                distTo[i][j] = distTo[i-1][minIndex] + energy(i, j);
                indexTo[i][j] = minIndex;
            }
        }
        ////////////////////////////////////////////////
        public int[] path()
        {
            double min = Double.MAX_VALUE;
            int minIndex = -1;
            for (int i = 0; i < height; i++)
            {
                if (distTo[width-1][i] < min)
                {
                    min = distTo[width-1][i];
                    minIndex = i;
                }
            }
            int[] path = new int[width];
            for (int i = width-1; i >= 0; i--)
            {
                path[i] = minIndex;
                minIndex = indexTo[i][minIndex];
            }
            return path;
        }
    }
   /////////////////////////////
    
   public int[] findHorizontalSeam()               // sequence of indices for horizontal seam
   {
       if (isTranspose)
           transpose();
       SeamSP seamSP = new SeamSP();
       return seamSP.path();
   }
   private void transpose()
   {
       //Color[][] temp = new Color[height][width];
       int[][] temp = new int[height][width];
       for (int i = 0; i < width; i++)
       {
           for (int j = 0; j < height; j++)
           {
               //temp[j][i] = myColor[i][j]; 
               temp[j][i] = colorMatrix[i][j];
           }
       }
       //myColor = temp;
       colorMatrix = temp;
       isTranspose = !isTranspose;
       
       int tmp = width;
       width = height;
       height = tmp;
   }
   
   

   public   int[] findVerticalSeam()                 // sequence of indices for vertical seam
   {
       if (!isTranspose)
       {
           transpose();
       }
       SeamSP seamSP = new SeamSP();
       return seamSP.path();
       //return findHorizontalSeam();
   }
   
   public void removeHorizontalSeam(int[] seam)   // remove horizontal seam from current picture
   {
       if (seam == null)
           throw new java.lang.NullPointerException();    
       //arraycopy(Object src, int srcPos, Object dest, int destPos, int length)
       if (isTranspose)
           transpose();
       
       if (seam.length != width || !isArrayValid(seam))
           throw new java.lang.IllegalArgumentException();
       if (height <= 1)
           throw new java.lang.IllegalArgumentException();
       for (int i = 0; i < width; i++)
       {
           //System.arraycopy(myColor[i], seam[i]+1, myColor[i], seam[i], height - seam[i] - 1);
           System.arraycopy(colorMatrix[i], seam[i]+1, colorMatrix[i], seam[i], height - seam[i] - 1);
       }
       height--;
   }
   public void removeVerticalSeam(int[] seam)     // remove vertical seam from current picture
   {
       if (seam == null)
           throw new java.lang.NullPointerException(); 
       if (!isTranspose)
       {
           transpose();
       }
       
       if (seam.length != width || !isArrayValid(seam))
           throw new java.lang.IllegalArgumentException();
       if (height <= 1)
           throw new java.lang.IllegalArgumentException();
       //removeHorizontalSeam(seam);
       for (int i = 0; i < width; i++)
       {
           //System.arraycopy(myColor[i], seam[i]+1, myColor[i], seam[i], height - seam[i] - 1);
           System.arraycopy(colorMatrix[i], seam[i]+1, colorMatrix[i], seam[i], height - seam[i] - 1);
       }
       height--;
       //transpose();
   }
   
   private boolean isArrayValid(int[] array)
   {
       for (int i = 0; i < array.length-1; i++)
       {
           if (Math.abs(array[i]-array[i+1]) > 1)
               return false;
       }
       return true;
   }
    public static void main(String[] args)
    {
        
    }
}