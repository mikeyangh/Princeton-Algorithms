public class SAP 
{
    private Digraph graphSAP;
   // constructor takes a digraph (not necessarily a DAG)
   public SAP(Digraph G)
   {
       if (G == null) throw new java.lang.NullPointerException();
       graphSAP = new Digraph(G);
   }

   // length of shortest ancestral path between v and w; -1 if no such path
   public int length(int v, int w)
   {
       if (ancestor(v, w) == -1)
           return -1;
       BreadthFirstDirectedPaths vPath = new BreadthFirstDirectedPaths(graphSAP, v);
       BreadthFirstDirectedPaths wPath = new BreadthFirstDirectedPaths(graphSAP, w);
       int minLength =  vPath.distTo(ancestor(v, w)) + wPath.distTo(ancestor(v, w));
       return minLength;
   }

   // a common ancestor of v and w that participates in a shortest ancestral path; -1 if no such path
   public int ancestor(int v, int w)
   {
       if (v < 0 || v > graphSAP.V() - 1 || w < 0 || w > graphSAP.V() - 1)
           throw new java.lang.IndexOutOfBoundsException();
       BreadthFirstDirectedPaths vPath = new BreadthFirstDirectedPaths(graphSAP, v);
       BreadthFirstDirectedPaths wPath = new BreadthFirstDirectedPaths(graphSAP, w);
       int minLength = Integer.MAX_VALUE;
       int ancestorIndex = -1;
       //boolean flag = false;
       for (int i = 0; i < graphSAP.V(); i++)
       {
           if (vPath.hasPathTo(i) && wPath.hasPathTo(i))
           {
               int lengthSum = vPath.distTo(i) + wPath.distTo(i);
               if (lengthSum < minLength)
               {
                   minLength = lengthSum;
                   ancestorIndex = i;
               }
           }
       }
       if (ancestorIndex == -1)
           return -1;
       return ancestorIndex;
   }

   // length of shortest ancestral path between any vertex in v and any vertex in w; -1 if no such path
   public int length(Iterable<Integer> v, Iterable<Integer> w)
   {
       if (ancestor(v, w) == -1)
           return -1;
       BreadthFirstDirectedPaths vPath = new BreadthFirstDirectedPaths(graphSAP, v);
       BreadthFirstDirectedPaths wPath = new BreadthFirstDirectedPaths(graphSAP, w);
       int minLength =  vPath.distTo(ancestor(v, w)) + wPath.distTo(ancestor(v, w));
       return minLength;
   }

   // a common ancestor that participates in shortest ancestral path; -1 if no such path
   public int ancestor(Iterable<Integer> v, Iterable<Integer> w)
   {
       BreadthFirstDirectedPaths vPath = new BreadthFirstDirectedPaths(graphSAP, v);
       BreadthFirstDirectedPaths wPath = new BreadthFirstDirectedPaths(graphSAP, w);
       int minLength = Integer.MAX_VALUE;
       int ancestorIndex = -1;
       //boolean flag = false;
       for (int i = 0; i < graphSAP.V(); i++)
       {
           
           if (vPath.hasPathTo(i) && wPath.hasPathTo(i))
           {
               int lengthSum = vPath.distTo(i) + wPath.distTo(i);
               if (lengthSum < minLength)
               {
                   minLength = lengthSum;
                   ancestorIndex = i;
               }
           }
       }
       if (ancestorIndex == -1) 
           return -1;
       return ancestorIndex;
   }

   // do unit testing of this class
   public static void main(String[] args)
   {
       In in = new In("wordnet/digraph1.txt");
       //In in = new In(args[0]);
       Digraph G = new Digraph(in);
       SAP sap = new SAP(G);
       while (!StdIn.isEmpty()) 
       {
           int v = StdIn.readInt();
           int w = StdIn.readInt();
           int length   = sap.length(v, w);
           int ancestor = sap.ancestor(v, w);
           StdOut.printf("length = %d, ancestor = %d\n", length, ancestor);
       }
       
   }
}