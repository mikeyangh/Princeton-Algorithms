public class WordNet 
{
    private int N;
    private ST<String, Queue<Integer>> st = new ST<String, Queue<Integer>>();
    private Digraph hypernymsGraph;
    private SAP mysap;
    private ST<Integer, String> map = new ST<Integer, String>();
   // constructor takes the name of the two input files
   public WordNet(String synsets, String hypernyms)
   {
       //private Digraph hypernymsGraph;
       synsetsInput(synsets);
       hypernymsInput(hypernyms);
       if (!isRootedDAG(hypernymsGraph))
           throw new java.lang.IllegalArgumentException();
       mysap = new SAP(hypernymsGraph);
   }
   
   private boolean isRootedDAG(Digraph G)
   {
       if (G == null) throw new java.lang.NullPointerException();
       DirectedCycle checkcycle = new DirectedCycle(G);
       if (checkcycle.hasCycle())
           return false;
       int countRoot = 0;
       for (int i = 0; i < G.V(); i++)
       {
           if (G.outdegree(i) == 0)
           {
               countRoot++;
           }
       }
       if (countRoot != 1)
           return false;    
       return true;
   }
   
   private void synsetsInput(String synsets)
   {
       In input = new In(synsets);
       N = input.readAllLines().length;
       In in = new In(synsets);
       while (!in.isEmpty())
       {
           String line = in.readLine();
           String[] fields = line.split(",");
           int number = Integer.parseInt(fields[0]);
           map.put(number, fields[1]);
           String[] nounFields = fields[1].split(" ");
           for (int i = 0; i < nounFields.length; i++)
           {
               String key = nounFields[i];
               if (!st.contains(key))
               {
                   st.put(key, new Queue<Integer>());
               }
               Queue<Integer> queue = st.get(key);
               queue.enqueue(number);
           }
       }
   }
   
   private void hypernymsInput(String hypernyms)
   {
       //In input = new In(hypernyms);
       //int N = input.readAllLines().length;
       hypernymsGraph = new Digraph(N);
       In input = new In(hypernyms);
       while (!input.isEmpty())
       {
           String[] fields = input.readLine().split(",");
           int[] numbers = new int[fields.length]; 
           numbers[0] = Integer.parseInt(fields[0]);
           for (int i = 1; i < fields.length; i++)
           {
               numbers[i] = Integer.parseInt(fields[i]);
               hypernymsGraph.addEdge(numbers[0], numbers[i]);
           }
       }
   }

   // returns all WordNet nouns
   public Iterable<String> nouns()
   {
       return st.keys();
   }

   // is the word a WordNet noun?
   public boolean isNoun(String word)
   {
       return st.contains(word);
   }

   // distance between nounA and nounB (defined below)
   public int distance(String nounA, String nounB)
   {
       if (!isNoun(nounA) || !isNoun(nounB))
           throw new java.lang.IllegalArgumentException();
       return mysap.length(st.get(nounA), st.get(nounB));
   }

   // a synset (second field of synsets.txt) that is the common ancestor of nounA and nounB
   // in a shortest ancestral path (defined below)
   public String sap(String nounA, String nounB)
   {
       if (!isNoun(nounA) || !isNoun(nounB))
           throw new java.lang.IllegalArgumentException();
       return map.get(mysap.ancestor(st.get(nounA), st.get(nounB)));
   }

   // do unit testing of this class
   public static void main(String[] args)
   {
       /*
       String str = "34,AIDS acquired_immune_deficiency_syndrome,a serious (often fatal) disease of the immune system transmitted through blood products especially by sexual contact or contaminated needles";
       StdOut.println(str);
       String[] fileds;
       fileds = str.split(",");
       StdOut.println(fileds[0]);
       StdOut.println(fileds[1]);
       StdOut.println(fileds[2]);*/
   }
}